class Parent
{
	int a;
	Parent()
	{
		System.out.println("In Parent Constructor");		
	}
	void parentMet()
	{
		System.out.println("In Parent Method");
	}
}
class Child extends Parent
{	
	int b;
	Child()
	{
		super();
		System.out.println("In Child Constructor");
	}
	void parentMet()
	{
		System.out.println("In Parent Method in Child");
	}
	void childMet()
	{		
		System.out.println("In Child Method ");
	}
}
class GrandChild extends Child
{
	int c;
	void grandChildMet()
	{
		c=a+b;
		System.out.println("In grandChild Method c=:"+c);
	}
}
class MultiLevelDemo
{
	public static void main(String as[])
	{
		GrandChild C=new GrandChild();
		C.a=100;
		C.b=200;
		C.childMet();
		C.parentMet();
		C.grandChildMet();
	}
}