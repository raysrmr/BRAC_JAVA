class CHNAJ1906
	{
		int desktops=24;
		int projector=1;
		float screenHight=4.5f;
		int noOfAssociates=22;
		void getTrainerName()
		{
			String trainer="Raffic";
			System.out.println("Trainer Name is :"+trainer);
		}
	}
class BOOffice
	{
		public static void main(String as[])
		{
			CHNAJ1906 code=new CHNAJ1906();
			System.out.println("No of Desktops :"+code.desktops);
			System.out.println("No of projector :"+code.projector);
			System.out.println("Projector Screen Hight :"+code.screenHight);
			System.out.println("No of Associattes :"+code.noOfAssociates);
			code.getTrainerName();
			
		}
	}