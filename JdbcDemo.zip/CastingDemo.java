import java.util.*;
class BankAccount
{
	int depositAmount;
	void depositMoney()
	{
		System.out.println("From Bank Account:"+depositAmount);
	}
	void withdrawMoney()
	{
		System.out.println("The withdraw money is:");
	}
	void applyFixedDeposit()
	{
		System.out.println("From applyFixedDeposit:");
	}
}
class NRIAccount extends BankAccount
{
	void applyFixedDeposit()
	{
		System.out.println("In applyFixedDeposit from NRIAccount");
	}	
}
class SeniorCitizenAccount extends BankAccount
{
	void applyFixedDeposit()
	{
	System.out.println("In SeniorCitizenAccount the applyFixedDeposit");
	}
}

class CastingDemo
{
	public static void main(String args[])
	{
		implicitCasting();
		explicitCasting();
		tryInstanceOf();
	}
	static void implicitCasting()
	{
		NRIAccount O1=new NRIAccount();
		BankAccount V1;
		V1=O1;
		V1.applyFixedDeposit();
	}
	static void explicitCasting()
	{
		BankAccount O1=new NRIAccount();
		NRIAccount V1;
		O1.depositAmount=3500;
		V1=(NRIAccount)O1;		
		V1.depositMoney();
	}
	static void tryInstanceOf()
	{
		BankAccount O1=new NRIAccount();
		BankAccount O2=new NRIAccount();
		BankAccount O3=new SeniorCitizenAccount();
		if(O1 instanceof NRIAccount)
		{
			System.out.println("Can type cast O1 to NRIAccount");
			O1=O2;
		}
		else
			{
			System.out.println("Can't type cast O1 to NRIAccount");			
		}
		if(O3 instanceof NRIAccount)
		{
			System.out.println("Can type cast O3 to NRIAccount");
			O3=O2;
		}
		else
			{
			System.out.println("Can't type cast O3 to NRIAccount");			
		}
		
	}
	
}
