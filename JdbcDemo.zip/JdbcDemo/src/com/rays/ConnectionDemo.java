package com.rays;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;

public class ConnectionDemo {

	public static void main(String[] args)throws Exception {
		Driver d=new com.mysql.jdbc.Driver();
		DriverManager.registerDriver(d);
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cts_demo", "root", "root");
		System.out.println("Connected...");

	}

}
