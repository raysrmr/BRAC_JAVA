import java.util.*;

public class TreeMapExample1
     {
        public static void main(String as[]) 
          {
		System.out.println("Tree Map Example!\n");
		TreeMap <String, String>tMap = new TreeMap<String, String>();
	
		tMap.put("FirstDay", "Sunday");
		tMap.put("SecondDay", "Monday");
		tMap.put("ThirdDay", "Tuesday");
		tMap.put("FourthDay", "Wednesday");
		tMap.put("FifthDay", "Thursday");
		tMap.put("SixthDay", "Friday");
		tMap.put("SeventhDay", "Saturday");
	
		System.out.println("Keys of tree map: " + tMap.keySet());

		System.out.println("Values of tree map: " + tMap.values());

		System.out.println("Key: 5 value: " + tMap.get("FifthDay")+ "\n");

		System.out.println("First key: " + tMap.firstKey() + " Value: " + tMap.get(tMap.firstKey()) + "\n");

		System.out.println("Last key: " + tMap.lastKey() + " Value: " + tMap.get(tMap.lastKey()) + "\n");

		System.out.println("Removing first data: " + tMap.remove(tMap.firstKey()));
		System.out.println("Now the tree map Keys: " + tMap.keySet());
		System.out.println("Now the tree map contain: " + tMap.values() + "\n");

		System.out.println("Removing last data: " + tMap.remove(tMap.lastKey()));
		System.out.println("Now the tree map Keys: " + tMap.keySet());
		System.out.println("Now the tree map contain: " + tMap.values());
	}
}