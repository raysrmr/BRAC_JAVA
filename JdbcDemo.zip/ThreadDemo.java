class ThreadDemo
   {
      public static void main(String as[])throws Exception
          {
               Thread T=new Thread();	
			   System.out.println(T.currentThread());
			   T.setName("Hari");
			   T.setPriority(Thread.MAX_PRIORITY);
			   System.out.println(T);
			   T.sleep(5000);
			   System.out.println("RAFFIC");
                
          }
                
   }