import java.io.*;
class ExceDemo
{
	public static void main(String as[])throws IOException
	{
		System.out.println("Main Starts Here...");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Two Numbers:");
		try{
		int a=Integer.parseInt(br.readLine());
		int b=Integer.parseInt(br.readLine());		
		int c=a/b;
		System.out.println("Answer C:"+c);
		}catch(ArithmeticException ae)
		{
			System.out.println("You cannot divide by zero...");
		}
		catch(NumberFormatException ne)
		{
			System.out.println("You cannot enter text value...");
		}
		
		System.out.println("Main Ends Here...");
	}
}