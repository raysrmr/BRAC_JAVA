
public class MainTh extends Thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainTh mt=new MainTh();
		mt.start();
		mt.start();		
	}
	public void run()
	{
		System.out.println("In Run");
	}

}
