class StudentRecord1
{
	StudentRecord1()
	{
		System.out.println("From Default Constructor");
	}
	StudentRecord1(int regNo)
	{
		System.out.println("From Param Constructor Reg No:"+regNo);
	}
	void printDetails()
	{
		System.out.println("From Print Details Method");
	}
}
class MainStudent1
{
	public static void main(String as[])
	{
		StudentRecord1 sr1=new StudentRecord1();
		new StudentRecord1(1001);
		sr1.printDetails();
	}
}
