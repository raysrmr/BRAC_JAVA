package com.aip.model.entity;

public class User {

}
