package com.aip.model.inter;

public interface UserDAO {
	
}
