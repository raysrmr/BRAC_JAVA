package com.aip.model.inter;

import com.aip.model.entity.Defaulter;

public interface DefaulterDAO {
	public int saveDefaulter(Defaulter def);
	public int updateDefaulter(Defaulter def);
	public int deleteDefaulter(int userid);
}
