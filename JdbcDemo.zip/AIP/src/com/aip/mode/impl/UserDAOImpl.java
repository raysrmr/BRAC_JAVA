package com.aip.mode.impl;

import com.aip.model.inter.UserDAO;

public class UserDAOImpl implements UserDAO {

}
