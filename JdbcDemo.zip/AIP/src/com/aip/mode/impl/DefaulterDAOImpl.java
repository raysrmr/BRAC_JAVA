package com.aip.mode.impl;

import com.aip.model.entity.Defaulter;
import com.aip.model.inter.DefaulterDAO;

public class DefaulterDAOImpl implements DefaulterDAO {

	@Override
	public int saveDefaulter(Defaulter def) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateDefaulter(Defaulter def) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteDefaulter(int userid) {
		// TODO Auto-generated method stub
		return 0;
	}

}
