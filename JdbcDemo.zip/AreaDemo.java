class AreaDemo
{
	
	void areaMet(int a,int b)
	{
		int area=a*b;
		System.out.println("Area of Rectangle= "+area);
	}
	void areaMet(double a)
	{
		double area=3.14*a*a;
		System.out.println("Area of Circle= "+area);
	}
}