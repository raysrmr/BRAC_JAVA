import java.io.*;
class ExceDemo1
{
	public static void main(String as[])throws IOException
	{
		System.out.println("Main Starts Here...");		
		System.out.println("Enter Two Numbers:");
		try(BufferedReader br=new BufferedReader(new InputStreamReader(System.in));)
		{
		int a=Integer.parseInt(br.readLine());
		int b=Integer.parseInt(br.readLine());		
		int c=a/b;
		System.out.println("Answer C:"+c);		
		}catch(Exception e)
		{
			System.out.println("Exception Handled...");
			System.out.println(e);
			System.out.println(e.getClass());
			System.out.println(e.getMessage());			
		}		
		finally
		{
			System.out.println("Write Important code to excute here");
		}		
		System.out.println("Main Ends Here...");
	}
}