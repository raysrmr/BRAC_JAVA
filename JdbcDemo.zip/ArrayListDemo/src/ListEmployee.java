import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ListEmployee {

	public static void main(String[] args)throws IOException {
		
		Employee emp=new Employee();
		ArrayList<Employee> list=insertEmployee(emp);
		getEmployee(list);
	}
	static ArrayList insertEmployee(Employee emp)throws IOException
	{
		    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		    System.out.println("Enter No of Emplyee:");
		    int n=Integer.parseInt(br.readLine());
		    ArrayList< Employee> empList=new ArrayList<Employee>();
		    for(int i=0;i<n;i++)
		    {
		    	System.out.print("ID:");
		    	int id=Integer.parseInt(br.readLine());
		    	System.out.print("Name:");
		    	String name=br.readLine();
		    	System.out.print("Department:");
		    	String dept=br.readLine();
		    	System.out.print("Salary:");
		    	double salary=Double.parseDouble(br.readLine());
		    	empList.add(new Employee(id, name, dept, salary));
		    }
		    return empList;
	}
	static void getEmployee(ArrayList<Employee> list)
	{
			for(Employee emp:list)
			{
				System.out.println(emp.getId()+"\t"+emp.getName()+"\t"+emp.getDept()+"\t"+emp.getSalary());
			}
	}
}
