import java.io.*;
class ReaderDemo
{
	public static void main(String as[])throws FileNotFoundException,IOException
	{
		FileReader fis=new FileReader("D:\\aj1906\\FirstPro.java");		
		BufferedReader br=new BufferedReader(fis);
		String a;		
		while((a=br.readLine())!=null)
		{
			System.out.print(a);
			//data.append(""+(char)a);
		}
		//System.out.print(data);
	}
}