import java.util.*;
class HashSetDemo1
{
	public static void main(String as[])
	{
		HashSet<String> hSet=new HashSet<String>();
		hSet.add(new String("Hari"));
		hSet.add(new String("is"));
		hSet.add(new String("not "));
		hSet.add(new String("Sleeping"));
		hSet.add(new String("in class"));
		hSet.add(new String("Room"));
		hSet.add(new String("Room"));
		
		System.out.println(hSet);
		
		Iterator itr=hSet.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
			System.out.println("After Removed....");
		//hSet.remove(2);
		hSet.remove("not ");
		Iterator itr1=hSet.iterator();
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		}
	}
}