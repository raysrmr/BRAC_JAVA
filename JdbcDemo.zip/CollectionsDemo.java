import java.util.*;
class CollectionsDemo
{
	public static void main(String as[])
	{
		ArrayList<Integer> aList=new ArrayList<Integer>();
		aList.add(new Integer(1001));
		aList.add(new Integer(1004));
		aList.add(new Integer(1002));			
		aList.add(new Integer(1005));
		aList.add(new Integer(1003));
		
		System.out.println("Before Sorting :"+aList);
		Collections.sort(aList);
		System.out.println("After Sorting :"+aList);
		
		Collections.shuffle(aList);
		System.out.println("After Shuffle :"+aList);
		
		System.out.println(Collections.max(aList));
		
	}
}