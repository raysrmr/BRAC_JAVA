package com.rays.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.rays.dao.EmployeeDAO;
import com.rays.dao.EmployeeDAOImpl;
import com.rays.model.ConnectionFactory;
import com.rays.model.Employee;

public class EmployeeMain {

	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public static void main(String as[])throws IOException
	{				
		EmployeeDAO edao=new EmployeeDAOImpl();
		do {
			System.out.println("Select your option:");
			System.out.println("1.Add Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Show All Employee");
			System.out.println("4.Remove Employee");
			System.out.println("5.Get By Employee");
			System.out.println("Press Any Key to Exit...");
			int choice=Integer.parseInt(br.readLine());
		switch (choice) {
		case 1:			
			System.out.println("Enter Employee Details:");			
			int status1=edao.saveEmployee(getData());
			if(status1==1)
			{
				System.out.println("Employee Added...");
			}
			else
			{
				System.out.println("Error in Adding...");
			}
			break;
		case 2:	
			System.out.print("Enter Employee Details to Update:");
			int status2=edao.updateEmployee(getData());
			if(status2==1)
			{
				System.out.println("Employee Updated...");
			}
			else
			{
				System.out.println("Error in Updating...");
			}
			break;
		case 3:		
			List<Employee> empList=edao.getAllEmployee();
			System.out.println("ID\tName\t\tAge\tSalary");
			for(Employee empLocal:empList)
			{
				System.out.println(empLocal.getEmpid()+"\t"+empLocal.getEmpname()+"\t\t"+empLocal.getEmpage()+"\t"+empLocal.getEmpsalary());
			}
			break;
		case 4:			
			System.out.print("Enter Employee Id to Remove : ");			
			int status3= edao.deleteEmployee(Integer.parseInt(br.readLine()));
			if(status3==1)
			{
				System.out.println("Employee Removed...");
			}
			else
			{
				System.out.println("Error in Deleting...");
			}
		case 5:
			System.out.print("Enter Employee Id : ");
			Employee empbyid=edao.getByEmployeeId(Integer.parseInt(br.readLine()));
			if(empbyid!=null)
				System.out.println(empbyid.getEmpid()+"\t"+empbyid.getEmpname()+"\t\t"+empbyid.getEmpage()+"\t"+empbyid.getEmpsalary());
			else
				System.out.println("Employee Not Found...");
			break;
		default:
			System.out.println("Enter Correct Option...");
			break;
		}
		System.out.print("Do you want to Continue 1. Yes   2. No   :");
		}while(Integer.parseInt(br.readLine())==1);		
		ConnectionFactory.closeConn();
		System.out.println("Employee Management System Closed...");
	}
	static Employee getData()throws IOException
	{
		System.out.print("ID:");
		int empid=Integer.parseInt(br.readLine());
		System.out.print("Name:");
		String empname=br.readLine();
		System.out.print("Age:");
		int empage=Integer.parseInt(br.readLine());
		System.out.println("Salary:");
		double empsalary=Double.parseDouble(br.readLine());
		Employee emp=new Employee(empid, empname, empage, empsalary);
		return emp;
	}
}
