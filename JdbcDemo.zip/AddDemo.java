import java.io.*;
class AddDemo
 {
	public static void main(String as[])throws Exception
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Welcome to Java World");		
		System.out.println("Enter First Number:");
		String a=br.readLine();
		int a1=Integer.parseInt(a);
		System.out.println("Enter Second Number:");
		String b=br.readLine();	
		int b1=Integer.parseInt(b);
		System.out.println(a+b);		
		System.out.println(a1+b1);		
	}
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 //int room=Integer.parseInt(br.readLine());