
public class StringPrinter {
	
		static  synchronized void printString(String A, String B)throws InterruptedException
		{
			System.out.print(A);
			Thread.sleep(500);
			System.out.println(B);
		}
}
