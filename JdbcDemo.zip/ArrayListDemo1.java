import java.util.*;
class ArrayListDemo1
{
	public static void main(String as[])
	{
		ArrayList<String> aList=new ArrayList<String>();
		aList.add(new String("Hari"));
		aList.add(new String("is"));
		aList.add(new String("not "));
		aList.add(new String("Sleeping"));
		aList.add(new String("in class"));
		aList.add(new String("Room"));
		aList.add(new String("Room"));
		
		System.out.println(aList);
		
		Iterator itr=aList.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
			System.out.println("After Removed....");
		//aList.remove(2);
		aList.remove("not ");
		Iterator itr1=aList.iterator();
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());
		}
	}
}