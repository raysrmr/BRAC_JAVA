
public class Square extends Shape {

	@Override
	double calculateArea() {
		double area=side*side;
		return area;
	}
	void volume()
	{
		System.out.println("From Volume");
	}

}
