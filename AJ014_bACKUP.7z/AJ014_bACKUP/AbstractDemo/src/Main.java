

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Shape S=new Square();
		S.side=100;
		System.out.println(S.calculateArea());
	//	S.volume();// you cannot access derived class methods using base class object referred by derived class
		
	}

}
