
public abstract class Shape {
	int side;
	abstract double calculateArea();
}
