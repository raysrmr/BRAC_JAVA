package com.rays.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestBook {

	@Test
	public void testBookTitle() {
		try {
			Books b=new Books();
			b.setTitle(null);
			//assertEquals("title cannot be null`", "null");
		} catch (Exception e) {
			// TODO: handle exception
			//assertEquals("title cannot be null`", e.getMessage());
		}
		
	}

}
