package com.rays.junit;

public class Books {

	private String title;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		if (title == null) {
			throw new IllegalArgumentException("title cannnot be null");
		} else {
			if (title.length() < 1) 
				throw new IllegalArgumentException("title is too short");
			else if (title.length() > 30)
				throw new IllegalArgumentException("title is too long");
		}
		this.title = title;
	}

}
