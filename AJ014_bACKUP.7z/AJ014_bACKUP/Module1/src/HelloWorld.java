
public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double buyingPrice=20.54;
		double sellingPrice=30.50;
		System.out.println("Buying price is "+buyingPrice);
		System.out.println("Selling price is "+sellingPrice);

	}
	
	static {
		System.out.println("In Static Block");
	}

}
