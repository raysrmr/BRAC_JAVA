import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Divide2Numbers {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Enter the 2 numbers");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try {
		int a=Integer.parseInt(br.readLine());
		int b=Integer.parseInt(br.readLine());
		int c=divMet(a, b);
		System.out.println("The quotient of "+a+"/"+b+"="+c);
		}catch (Exception e) {
             System.out.println(e.getClass().getName()+" caught");
             }
		finally {
			System.out.println("Inside finally block ");	
		}
		
	}
	static int divMet(int a,int b)throws DivideByZeroException
	{
		if(b==0)
		{
			throw new DivideByZeroException("Like Seriously Dont pass Zero");
		}else {
			return a/b;
		}
		
	}

}
