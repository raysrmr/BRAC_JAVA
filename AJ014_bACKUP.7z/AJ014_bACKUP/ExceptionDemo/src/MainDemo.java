import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Enter the 2 numbers");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try {
		int a=Integer.parseInt(br.readLine());
		int b=Integer.parseInt(br.readLine());
		int c=a/b;
		System.out.println("The quotient of "+a+"/"+b+"="+c);
		}catch (Exception e) {
             System.out.println("DivideByZeroException caught");
		}
		finally {
			System.out.println("Inside finally block");	
		}
		

	}

}
