
public class Aish extends Exception{

	public Aish(String msg)
	{		
		super(msg);
	}
}
