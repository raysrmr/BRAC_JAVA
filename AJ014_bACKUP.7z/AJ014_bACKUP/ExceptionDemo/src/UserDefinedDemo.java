import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class UserDefinedDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Start");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try {
		int a=Integer.parseInt(br.readLine());
		int b=Integer.parseInt(br.readLine());
		int c=divMet(a, b);
		System.out.println("C="+c);
		}catch (Exception e) {
             System.out.println("Catch Block "+e);
             }
		finally {
			System.out.println("End");	
		}
		
	}
	static int divMet(int a,int b)throws Aish
	{
		if(b==0)
		{
			throw new Aish("Like Seriously Dont pass Zero");
		}else {
			return a/b;
		}
		
	}

}
