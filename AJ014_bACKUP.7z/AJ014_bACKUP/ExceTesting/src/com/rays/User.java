package com.rays;

public class User {

	private String name;

	public void setName(String name) {

		if (name == null)
			throw new IllegalArgumentException("UserName cannot be blank");

		this.name = name;
	}

}
