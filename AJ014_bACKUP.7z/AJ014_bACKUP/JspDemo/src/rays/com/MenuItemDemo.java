package rays.com;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rays.model.MenuItem;
import com.rays.util.DateUtil;

/**
 * Servlet implementation class MenuItemDemo
 */
@WebServlet("/MenuItemDemo")
public class MenuItemDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MenuItemDemo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		List<MenuItem> menuItemList = new ArrayList<MenuItem>();
		try {
			menuItemList.add(
					new MenuItem(1, "Sandwich", 99, true, DateUtil.convertToDate("15/03/2017"), "Main course", true));
		
		menuItemList.add(
				new MenuItem(2, "Burger", 129, true, DateUtil.convertToDate("23/12/2017"), "Main course", false));
		menuItemList.add(
				new MenuItem(3, "pizza", 149, true, DateUtil.convertToDate("21/08/2018"), "Main course", false));
		menuItemList.add(
				new MenuItem(4, "french fries", 57, false, DateUtil.convertToDate("02/07/2017"), "Starters", true));
		menuItemList.add(
				new MenuItem(5, "chocolate brownie", 32, true, DateUtil.convertToDate("02/11/2022"),
				"Dessert", true));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.setAttribute("menuList", menuItemList);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
