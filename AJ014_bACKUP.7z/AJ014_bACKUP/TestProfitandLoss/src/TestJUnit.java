import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestJUnit {

	CalculateUtils cal=new CalculateUtils();
	@Test(expected=IllegalArgumentException.class)
   public void testPrintMessage() {
		int sellingPrice=-1;
		int buyingPrice=1;
	   boolean message = true;
      assertEquals(message,cal.calculateProfit(sellingPrice, buyingPrice));
   }
}