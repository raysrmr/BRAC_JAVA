import org.junit.Test;

public class CalculateUtils {

	@Test
	public boolean calculateProfit(int sellingPrice, int buyingPrice) {
		boolean result = false;
		if (sellingPrice >= 0 && buyingPrice >= 0)
			result = true;
		else if (buyingPrice < 0 && sellingPrice > 0)
			throw new IllegalArgumentException("Buying price or selling price cannot be lesser than 0");
		else if (buyingPrice > 0 && sellingPrice < 0)
			throw new IllegalArgumentException("Buying price or selling price cannot be lesser than 0");
		else if (sellingPrice < 0 && buyingPrice < 0)
			throw new IllegalArgumentException("Buying price or selling price cannot be lesser than 0");
		
		return result;
	}
}
