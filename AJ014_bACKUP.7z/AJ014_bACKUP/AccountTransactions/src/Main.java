import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*Enter the Account Number 

		1000321 

		Enter the Account Balance 

		5000 

		Enter 1 to deposit an amount, 2 to withdraw an amount */
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Account Number");
		String acNumber=sc.next();
		System.out.println("Enter the Account Balance");
		int balance=sc.nextInt();
		Account A=new Account(acNumber, balance);
		System.out.println(A);
		System.out.println("Enter 1 to deposit an amount, 2 to withdraw an amount");
		int option=sc.nextInt();
		int transactionAmount=0;
		switch (option) {
		case 1:
			System.out.println("Enter the amount to deposit");
			transactionAmount=sc.nextInt();
			A.deposit(transactionAmount);
			break;
		case 2:
			System.out.println("Enter the amount to withdraw");
			transactionAmount=sc.nextInt();
			A.withdraw(transactionAmount);		
		}

	}

}
