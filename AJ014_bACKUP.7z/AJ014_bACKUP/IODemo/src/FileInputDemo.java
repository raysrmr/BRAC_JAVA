import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileInputDemo {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		try(FileInputStream fis=new FileInputStream("D:\\employee1.txt")){
			
			int a;
			while((a=fis.read())!=-1)
			{
				System.out.print((char)a);
			}
			
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}

}
