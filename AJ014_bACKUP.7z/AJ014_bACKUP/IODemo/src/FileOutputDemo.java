import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class FileOutputDemo {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		try(FileInputStream fis=new FileInputStream("C:\\Users\\t-Mohamed\\Pictures\\Screenshots\\sch.png");
				FileOutputStream fos=new FileOutputStream("d:\\newemp.png")){
			
			int a;
			while((a=fis.read())!=-1)
			{
				fos.write(a);
			}
			System.out.println("Done...");
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}

}
