import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		try {
			FileWriter fw=new FileWriter("player.csv");
			
			System.out.println("Enter the name of the player");
			String name=bf.readLine();
			System.out.println("Enter the team name");
			String tname=bf.readLine();
			System.out.println("Enter the number of matches played");
			int nom=Integer.parseInt(bf.readLine());
			fw.append(name).append(",").append(tname).append(",").append(nom+"");
			fw.close();			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
