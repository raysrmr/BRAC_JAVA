import java.io.File;
import java.util.Date;

public class FileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File f=new File("\\Users\\t-Mohamed\\Downloads\\training_Demos\\DAOCURDDemo\\src\\com\\rays\\dao\\EmployeeDAO.java");
		System.out.println(f.length());
		System.out.println(f.getName());
		System.out.println(f.canRead());
		System.out.println(f.getPath());
		System.out.println(f.getAbsolutePath());
		System.out.println(f.lastModified());
		System.out.println(new Date(f.lastModified()));
	}

}
