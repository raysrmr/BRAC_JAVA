
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Main {

    public static void main(String[] args) {								
				Scanner sc = new Scanner(System.in);
				
				System.out.println("Enter the number of players");
				int players = Integer.parseInt(sc.nextLine());
				
				HashMap<String, Long> playerMap = new HashMap<String, Long>();
				
				for(int i = 0; i < players; i++){
					System.out.println("Enter the details of the player " + (i+1));
					String playerName = sc.nextLine();
					long runs = Long.parseLong(sc.nextLine());
					
					playerMap.put(playerName, runs);
				}
				
				Set<String> keys = playerMap.keySet();
				
				long max = 0;
				/*String bestPlayer = new String();
				
				for(String p :keys){					
					if(playerMap.get(p) > max){
						max = playerMap.get(p);
						bestPlayer = p;						
					}
				}							
					System.out.println(bestPlayer);
					sc.close();	*/
					
					
					ArrayList<String> pname=new ArrayList<>();
					ArrayList<Long> runs=new ArrayList<>();
					for(Map.Entry<String, Long> local_map:playerMap.entrySet())
					{
						runs.add(local_map.getValue());
						pname.add(local_map.getKey());
					}
					
					max=Collections.max(runs);
					int index=0;
					for(Long l:runs)
					{
						if(max==l)
						{
							index=0;
						}
						index++;
					}
					System.out.println(pname.get(index));
	}
}

