package com.rays.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.rays.connection.DbConnection;
import com.rays.model.User;

public class UserDaoImpl implements UserDao {

	Connection connection;
	public UserDaoImpl() {
		// TODO Auto-generated constructor stub
		connection = DbConnection.getConnection();
	}
	@Override
	public int addUser(User user) {
		// TODO Auto-generated method stub
		int result=0;
		try {
			PreparedStatement ps=connection.prepareStatement("insert into user values(?,?,?,?,?)");
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getFirstName());
			ps.setInt(4, user.getAge());
			ps.setString(5, user.getMobile());
			result=ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			result = 0;
			System.out.println("error in add user : "+e);
		}
		return result;
	}

	@Override
	public User getUser(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateUser(String userName, String password) {
		// TODO Auto-generated method stub
		boolean result=false;
		try {
			PreparedStatement ps=connection.prepareStatement("select us_username from user where us_username=? and us_password=?");
			ps.setString(1, userName);
			ps.setString(2, password);			
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				result =true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			result = false;
			System.out.println("error in validate user : "+e);
		}
		return result;
	}

}
