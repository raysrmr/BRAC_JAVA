package com.rays.dao;

import com.rays.model.User;

public interface UserDao {
	
	public int addUser(User user);
	public User getUser(String userName);
	public boolean validateUser(String userName, String password);
}
