package com.rays.connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {
	
	static Connection connection;
	
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prodemo", "root", "root");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Connection Creation  : "+e);
		}
		
		return connection;
	}

}
