package com.rays.model;

public class User {
	
	private String userName;
	private String password;
	private String firstName;
	private int age;
	private String mobile;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String userName, String password, String firstName, int age, String mobile) {
		super();
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.age = age;
		this.mobile = mobile;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	

}
