import java.util.Scanner;

public class SecureCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String url=sc.nextLine();
		System.out.println("Enter the start string");
		String startString=sc.next();
		
		if(url.startsWith(startString))
		{
			System.out.println("\""+url+"\" starts with \"https\"");
		}
		else
		{
			System.out.println("\""+url+"\" does not starts with \"https\"");
		}

	}

}
