import java.util.Scanner;

public class RedCross2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int tent[] = new int[n];
		int numberOfRefugees = 0;
		for (int i = 0; i < n; i++) {
			tent[i]=sc.nextInt();			
		}
		for(int temp:tent)
		{
			numberOfRefugees=numberOfRefugees+temp;
		}
		System.out.println(numberOfRefugees);
		sc.close();
	}

}
