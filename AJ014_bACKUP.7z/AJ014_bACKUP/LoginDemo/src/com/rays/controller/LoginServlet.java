package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String uname=request.getParameter("uname");
		String password=request.getParameter("password");
		HttpSession session=request.getSession();
		if(uname.equals("raysrmr") && password.equals("cts123"))
		{
			session.setMaxInactiveInterval(10);
			session.setAttribute("user", uname);
			session.setAttribute("login_time", new Date());
			Cookie cookie1=new Cookie("username", uname);
			//Cookie cookie2=new Cookie("login", ""+new Date());
			response.addCookie(cookie1);
			//response.addCookie(cookie2);
			request.getRequestDispatcher("SuccessServlet").forward(request, response);
			//response.sendRedirect("SuccessServlet");
		}else {
			pw.println("<center><h2 style=color:red;>Invalid UserName or Password</h2></center>");
			request.getRequestDispatcher("index.jsp").include(request, response);
		}
	}

}
