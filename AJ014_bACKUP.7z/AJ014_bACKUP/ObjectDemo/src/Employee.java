
public class Employee {
	
	private Integer id;
	private String empName;
	public Employee(Integer id, String empName) {
		super();
		this.id = id;
		this.empName = empName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", empName=" + empName + "]";
	}
	/*@Override
	public int hashCode() {		
		return id;
	}
	*/
	@Override
	public boolean equals(Object obj) {
		
		Employee emp3=(Employee)obj;
		
		if(this.id.equals(emp3.id) && this.empName.equals(emp3.empName))		
			return true;
		else
			return false;
	}
	
	
	
	

}
