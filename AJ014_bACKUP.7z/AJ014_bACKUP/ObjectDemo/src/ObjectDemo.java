
public class ObjectDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp1=new Employee(1001, "Rays");
		Employee emp2=new Employee(1001, "Rays");
		
		System.out.println(emp1);
		System.out.println(emp2);
		

		
		if (emp1.equals(emp2)) { 
            System.out.println("Equal "); 
        } else { 
            System.out.println("Not Equal "); 
        } 
		
		Object obj = new String("Raffic"); 
		Class c = obj.getClass(); 
		System.out.println("Class of Object obj is : " + c.getName()); 

	}

}
