
public class Square extends Shape {
	Integer side;
	
	public Square(Integer side) {
		super("Square");
		this.side = side;
	}

	public Integer getSide() {
		return side;
	}

	public void setSide(Integer side) {
		this.side = side;
	}

	Double calculateArea()
	{
		double area=(double)side*side;
		return area;
	}
}
