
public class Circle extends Shape {

	Integer radius;
	public Circle(Integer radius)
	{
		super("Circle");
		this.radius=radius;
	}
	
	public Integer getRadius() {
		return radius;
	}

	public void setRadius(Integer radius) {
		this.radius = radius;
	}

	Double calculateArea()
	{
		double area=(double)3.14*radius*radius;
		return area;
	}
}
