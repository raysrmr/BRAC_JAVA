
public class Rectangle extends Shape{

	Integer length; 
	Integer breadth;
	
	public Rectangle(Integer length, Integer breadth) {
		super("Rectangle");
		this.length = length;
		this.breadth = breadth;
	}

	public Integer getLength() {
		return length;
	}

	public void setLength(Integer length) {
		this.length = length;
	}

	public Integer getBreadth() {
		return breadth;
	}

	public void setBreadth(Integer breadth) {
		this.breadth = breadth;
	}

	Double calculateArea()
	{
		double area=(double)length*breadth;
		return area;
	}
}
