import java.text.DecimalFormat;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("1. Rectangle");
		System.out.println("2. Square");
		System.out.println("3. Circle");
		System.out.println("Area Calculator --- Choose your shape");
		int option=sc.nextInt();
		DecimalFormat df=new DecimalFormat("##.00");
		switch (option) {
		case 1:
			System.out.println("Enter length and breadth:");
			Integer length=sc.nextInt();
			Integer breadth=sc.nextInt();
			Shape R=new Rectangle(length, breadth); 
			System.out.println("Area of Rectangle is:"+df.format(R.calculateArea()));
			break;
		case 2:
			System.out.println("Enter side:");
			Integer side=sc.nextInt();
			Shape S=new Square(side);
			System.out.println("Area of Square is:"+df.format(S.calculateArea()));
			break;
		case 3:
			System.out.println("Enter Radius:");
			Integer radius=sc.nextInt();
			Shape C=new Circle(radius);
			System.out.println("Area of Circle is:"+df.format(C.calculateArea()));		
		}
	}

}
