import java.util.Scanner;

public class DayOfweek {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String dow[]=new String[] {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
		dow[0]="Sun";
		dow[1]="Mon";
		dow[2]="Tue";
		dow[3]="Wed";
		dow[4]="Thu";
		dow[5]="Fri";
		dow[6]="Sat";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the day number");
		int day=sc.nextInt();
		System.out.println("Day of the week is "+dow[day-1]);
		sc.close();
	}

}
