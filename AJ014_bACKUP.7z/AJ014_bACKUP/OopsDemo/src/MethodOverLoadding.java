
public class MethodOverLoadding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AreaDemo ad=new AreaDemo();
		ad.areaMet(12.45);
		ad.areaMet(91);
		ad.areaMet(20, 13);

	}

}
