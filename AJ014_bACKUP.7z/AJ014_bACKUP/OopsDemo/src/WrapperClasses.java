public class WrapperClasses
{
	static void overloadedMethod(short I)
    {
        System.out.println("Short Wrapper Class Type");
    }
    static void overloadedMethod(long I)
    {
        System.out.println("Long Wrapper Class Type");
    }
    static void overloadedMethod(double d)
    {
        System.out.println("Double Wrapper Class type");
    }
    public static void main(String[] args)
    {
        int i = 21;
        overloadedMethod(i);
    }
}