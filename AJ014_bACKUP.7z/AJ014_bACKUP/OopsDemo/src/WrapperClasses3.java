public class WrapperClasses3
{	
    public static void main(String[] args)
    {
        int i = 21;
        Integer I=i;
        System.out.println(I);
        
        Integer I1=new Integer(101);
        int i1=I1;
        System.out.println(i1);
                
        
    }
}