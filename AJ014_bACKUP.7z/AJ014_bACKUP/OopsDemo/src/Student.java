
public class Student {
	int regno;
	String sname;
	public Student() {
		System.out.println("From student Constructor");
	}
	
	Student(String sname)
	{
		System.out.println("From param Constructor :"+sname);
	}
	
	Student(int regno,String sname)
	{
		this.regno=regno;
		this.sname=sname;
	}
	void printStudent()
	{
		System.out.println("Reg Number :"+ regno);
		System.out.println("student Name :"+ sname);
	}

}
