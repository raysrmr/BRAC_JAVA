
public class ConsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student st=new Student();
		new Student("Raffic");
		Student st1=new Student(1001, "Rays");
		st.printStudent();
	}

}
