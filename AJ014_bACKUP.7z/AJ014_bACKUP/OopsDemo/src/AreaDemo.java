
public class AreaDemo {
	
	void areaMet(int a)
	{
		int area=a*a;
		System.out.println("Area of Square : "+area);
	}
	void areaMet(int a,int b)
	{
		int area=a*b;
		System.out.println("Area of Reactangle : "+area);
	}
	void areaMet(double a)
	{
		double area=3.14*a*a;
		System.out.println("Area of Circle : "+area);
	}

}
