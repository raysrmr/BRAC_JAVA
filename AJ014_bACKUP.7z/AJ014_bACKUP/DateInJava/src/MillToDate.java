// Java program to convert milliseconds 
// to a Date format 

import java.text.DateFormat; 
import java.text.SimpleDateFormat; 
import java.util.Date; 

public class MillToDate { 
	public static void main(String args[]) 
	{ 
		
		long miliSec = 3010; 
		
		DateFormat simple = new SimpleDateFormat("dd MMM yyyy HH:mm:ss:SSS Z"); 
		
		Date result = new Date(miliSec); 
		
		System.out.println(simple.format(result)); 
	} 
} 
