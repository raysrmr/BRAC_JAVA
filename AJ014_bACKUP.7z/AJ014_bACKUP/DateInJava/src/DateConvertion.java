import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateConvertion {

	public static void main(String as[]) throws ParseException {
		// Simple Date
		Date d = new Date();
		System.out.println(d);

		// Convert Date to String
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String date = sdf.format(new Date());
		System.out.println(date);   

		// Convert String to Date
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		String dateInString = "31-08-2019 10:20:56";
		Date date1 = sdf1.parse(dateInString);
		System.out.println(date1); //  Tue Sep 10 10:28:28 IST 2019

		Calendar calendar = Calendar.getInstance();
		Date date2 = calendar.getTime();
		System.out.println(date2);
		calendar.add(Calendar.DAY_OF_MONTH, 5);
		System.out.println(calendar.getTime());
	

	}
}
