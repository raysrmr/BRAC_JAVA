import java.util.Scanner;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product P=new Product();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the product id");
		P.setId(sc.nextLong());
		System.out.println("Enter the product name");
		P.setProductName(sc.next());
		System.out.println("Enter the supplier name");
		P.setSupplierName(sc.next());
		
		
		System.out.println("Product Id is "+P.getId());
		System.out.println("Product Name is "+P.getProductName());
		System.out.println("Supplier Name is "+P.getSupplierName());

	}

}
