import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of GenCs");
		int n=sc.nextInt();
		Trainee T[]=new Trainee[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Employee Id");
			int employeeId=sc.nextInt();
			System.out.println("Enter Name");
			String name=sc.next();
			T[i]=new Trainee(employeeId, name);
		}
		
		for(Trainee T1:T)
		{
			T1.display();
		}
	}

}
