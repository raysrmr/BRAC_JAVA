package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CardTest {

	CardTesting ct=new CardTesting();
	@Test
	void test() {
		CardTesting ct=new CardTesting();
		String ccNUmber="1122334455667788";
		String actual=ct.task(ccNUmber);
		String expectedValue="XXXXXXXXXXXX7788";
		assertEquals(expectedValue, actual);
	}
		
}
