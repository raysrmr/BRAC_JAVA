package testing;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import testing.JUnitTesting;

class AgeChecker {

	@Test
	void test() {
		
		JUnitTesting jTest=new JUnitTesting();
		boolean result=jTest.ageChecker(27);
		assertEquals(true, result);
	}
}
