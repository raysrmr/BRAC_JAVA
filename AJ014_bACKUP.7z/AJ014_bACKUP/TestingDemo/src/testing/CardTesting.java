package testing;

public class CardTesting {
	
	public String task(String ccNumber)
	{
		//return ccNumber;
		return "XXXXXXXXXXXX" + ccNumber.substring(ccNumber.length()-4);
	}

}
