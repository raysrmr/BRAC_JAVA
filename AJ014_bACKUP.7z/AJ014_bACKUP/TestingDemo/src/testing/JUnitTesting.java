package testing;

public class JUnitTesting {

	public boolean ageChecker(int age) {
		if (age >= 18)
			return true;
		else
			return false;
	}

}
