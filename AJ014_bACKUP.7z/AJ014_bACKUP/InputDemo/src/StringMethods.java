
public class StringMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="Java is a platform independent language";
		String s2="Java is a platform independent language";
		String s5="rays@com;raffic@com;afee@com";
		String mail[]=s5.split("@");
		
		String s3=new String("         Cognizant");
		String s4=new String("cognizant");
		
		System.out.println(s1.length());
		System.out.println(s1.charAt(10));
		System.out.println(s1.indexOf('a'));
		System.out.println(s1.indexOf('a',12));
		System.out.println(s1.lastIndexOf('a'));
		System.out.println(s1.lastIndexOf('a',33));
		System.out.println(s1.indexOf("is"));
		System.out.println(s1.equals(s2));
		System.out.println(s3.equals(s4));
		System.out.println(s1.equalsIgnoreCase(s2));
		System.out.println(s1.startsWith("Jav"));
		System.out.println(s1.replace('a', '@'));
		System.out.println(s3);
		System.out.println(s3.trim());
		System.out.println(s1.substring(4));
		System.out.println(s1.substring(4,9));
		System.out.println(s1+s2);
		System.out.println(s4+s3);
		System.out.println(s3.concat(s4));
		
		System.out.println(mail[0]);
		System.out.println(mail[1]);
		System.out.println(mail[2]);
	}

}
