
public class WhileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		short a=0;
		while(a<10)
		{
			System.out.println("In While Loop :"+a);
			a++;
		}
		
		a=0;
		do {
			System.out.println("In Do While Loop :"+a);
			a++;
		}while(a<20);

	}

}
