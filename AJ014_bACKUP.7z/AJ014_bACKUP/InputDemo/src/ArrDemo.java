class ArrDemo
{
	public static void main(String as[])
	{
		int reg_no[]={1001,1002,1003,1004,1005};
		String stu_name[]={"Ram","Ravi","Rajesh","Raffic","Rays"};
		for(int i=0;i<reg_no.length;i++)
		   System.out.println("Reg No:"+reg_no[i]+"\t Student Name:"+stu_name[i]);
	   
		for(int pr:reg_no)
		{
			System.out.println(pr);
		}
		
		for(String sname:stu_name)
		{
			System.out.println(sname);
		}
	}
}