public class OuterClass
{
	static void staMet()
	{
		System.out.println("Static Type ...With out Return type and Without Arguments");
	}
	void withOutBoth()
	{
		System.out.println("With out Return type and Without Arguments");
	}
	void withArgu(String sname)
	{
		System.out.println("With out Return type and With Arguments : "+sname);
	}
	int withReturn()
	{
		int ans=1001;
		System.out.println("With Return type and Without Arguments : ");
		return ans;
	}
	double withBoth(int a,int b)
	{
		double c=(double)a/b;
		System.out.println("With Return type and With Arguments ");
		return c;
	}

}
