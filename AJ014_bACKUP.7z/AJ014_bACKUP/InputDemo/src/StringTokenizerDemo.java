import java.util.*;
class StringTokenizerDemo
{
	public static void main(String as[])
	{		
		String st1=new String("http://127.0.0.1:3306/cts/index.jsp");
		String ss[]=st1.split("://.");
		for(String p:ss)
			System.out.println(p);
		
		System.out.println("*****************************");
		
		StringTokenizer st=new StringTokenizer(st1,"://.");
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken());
		}
	}
}