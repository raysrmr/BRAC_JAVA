import java.util.Scanner;

public class RunDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Name:");
		String name=sc.next();
		System.out.println("Enter Your Age:");
		int age=sc.nextInt();
		System.out.println("Enter Your Height:");
		float height=sc.nextFloat();
		
		System.out.println("Name "+name);
		System.out.println("Age "+age);
		System.out.println("Height "+height);
	}

}
