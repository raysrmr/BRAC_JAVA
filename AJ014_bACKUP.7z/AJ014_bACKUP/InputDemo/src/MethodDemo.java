
public class MethodDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodDemo md=new MethodDemo();
		md.withOutBoth();
		md.withArgu("Raffic");
		int a=md.withReturn();
		System.out.println("Return from withReturn :"+a);
		double c=md.withBoth(5, 2);
		System.out.println("Return from withBoth :"+c);
		md.staMet();
		MethodDemo.staMet();
		staMet();
	}
	static void staMet()
	{
		System.out.println("Static Type ...With out Return type and Without Arguments");
	}
	void withOutBoth()
	{
		System.out.println("With out Return type and Without Arguments");
	}
	void withArgu(String sname)
	{
		System.out.println("With out Return type and With Arguments : "+sname);
	}
	int withReturn()
	{
		int ans=1001;
		System.out.println("With Return type and Without Arguments : ");
		return ans;
	}
	double withBoth(int a,int b)
	{
		double c=(double)a/b;
		System.out.println("With Return type and With Arguments ");
		return c;
	}

}
