class ModuleDemo
{
	int a;
	static int b;
	void printMet()
	{
		System.out.println("a="+a+"\t b="+b);
	}
}
public class StaticDemo {

	public static void main(String[] args) {
		ModuleDemo md1=new ModuleDemo();
		ModuleDemo md2=new ModuleDemo();
		ModuleDemo md3=new ModuleDemo();
		md1.a=100;
		md1.b=200;
		md2.a=300;
		md2.b=400;
		md3.a=500;
		md3.b=600;
		
		md1.printMet();
		md2.printMet();
		md3.printMet();

	}

}
