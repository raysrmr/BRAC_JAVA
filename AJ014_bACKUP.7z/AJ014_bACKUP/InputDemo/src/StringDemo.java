
public class StringDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="Cognizant";
		String s2="Cognizant";
		String s3=new String("Cognizant");
		String s4=new String("Cognizant");
		
		if(s1==s2)
			System.out.println("Hi");
		
		if(s3==s4)
			System.out.println("Hello");

	}

}
