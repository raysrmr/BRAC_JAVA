
public class ClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OuterClass oc=new OuterClass();
		oc.withOutBoth();
		oc.withArgu("Raffic");
		int a=oc.withReturn();
		System.out.println("Return from withReturn :"+a);
		double c=oc.withBoth(5, 2);
		System.out.println("Return from withBoth :"+c);
		oc.staMet();
		OuterClass.staMet();		
	}
}
