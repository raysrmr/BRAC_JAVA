package basic;

public class TestingClass {
	
	public int add(int a,int b) {
		return a+b;
	}

}
