package basic;
import static org.junit.Assert.*;

import org.junit.Test;

public class AddTest {

	@Test
	public void addTest() {
		TestingClass tc=new TestingClass();
		int ans = tc.add(10, 20);
		assertEquals(3, ans);
	}

}
