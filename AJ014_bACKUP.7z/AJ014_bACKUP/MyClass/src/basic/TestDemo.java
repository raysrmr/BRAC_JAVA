package basic;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDemo {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
