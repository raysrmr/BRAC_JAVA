


import static org.junit.Assert.*;

import org.junit.Test;

public class TestBook {

	@Test
	public void testBookTitle() {
		try {
			Books b=new Books();
			b.setTitle(null);
			
			fail();
		} catch (Exception e) {
			// TODO: handle exception
			assertEquals("title cannnot be null", e.getMessage());
		}
		
	}

}
