package exception;
import static org.junit.Assert.*;

import org.junit.Test;

public class ExceTest {

	@Test(expected = java.lang.ArithmeticException.class)
	public void test() {
		
		ExpectedExcepDemo ex=new ExpectedExcepDemo();
		int actual=ex.div(5, 0);
		System.out.println("Div  : "+actual);
		assertEquals(2, actual);
	}

}
