import java.util.Scanner;
import java.util.Set;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of Box");
		int noOfBox = sc.nextInt();
		HashSet<Box> sbox = new HashSet<>();
		for (int i = 0; i < noOfBox; i++) {
			System.out.println("Enter the Box " + (i + 1) + " details");
			System.out.println("Enter Length");
			double length = sc.nextDouble();
			System.out.println("Enter Width");
			double width = sc.nextDouble();
			System.out.println("Enter Height");
			double height = sc.nextDouble();
			Box box1 = new Box(length, width, height);
			sbox.add(box1);
		}
		
		System.out.println("Unique Boxes in the Set are ");

		for (Box b : sbox) {
			System.out.println(b);
		}

	}

}
