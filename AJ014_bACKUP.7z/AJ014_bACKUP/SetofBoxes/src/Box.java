
public class Box {

	private Double length;
	private Double width;
	private Double height;

	public Box() {
		super();
	}

	public Box(Double length, Double width, Double height) {
		super();
		this.length = length;
		this.width = width;
		this.height = height;
	}

	public Double getLength() {
		return length;
	}

	public void setLength(Double length) {
		this.length = length;
	}

	public Double getWidth() {
		return width;
	}

	public void setWidth(Double width) {
		this.width = width;
	}

	public Double getHeight() {
		return height;
	}

	public void setHeight(Double height) {
		this.height = height;
	}

	@Override
	public String toString() {
		return "Length=" + length + " Width=" + width + " height=" + height + "Volume="
				+ (this.length * this.height * this.width);
	}

	@Override
	public boolean equals(Object obj) {
		System.out.println("In Equlas");
		if (obj instanceof Box) {
			Box b = (Box) obj;
			// System.out.println(this.length * this.height * this.width);
			return (this.length * this.height * this.width) == (b.getLength() * b.getHeight() * b.getWidth());
		} else
			return false;

	}

	@Override
	public int hashCode() {
		System.out.println("In HashCode");
		final int prime = 31;
		int result = 1;
		result = prime * result + ((height == null) ? 0 : height.hashCode());
		result = prime * result + ((length == null) ? 0 : length.hashCode());
		result = prime * result + ((width == null) ? 0 : width.hashCode());
		return result;
	}
}
