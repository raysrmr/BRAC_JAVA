public class Employee implements Comparable<Employee>
{
    private int associateId;
    private String name;
    private int score;
    
    public Employee(){}
    public Employee(int associateId, String name) {
       super();
       this.associateId = associateId;
       this.name = name;
    }
    
    public int getScore() {
       return score;
    }
    public void setScore(int score) {
       this.score = score;
    }
    public Employee(int associateId, String name, int score) {
       super();
       this.associateId = associateId;
       this.name = name;
       this.score = score;
    }
    public int getAssociateId() {
       return associateId;
    }
    public void setAssociateId(int associateId) {
       this.associateId = associateId;
    }
    public String getName() {
       return name;
    }
    public void setName(String name) {
       this.name = name;
    }
    
    @Override
    public String toString() {
       return "Employee [associateId=" + associateId + ", name=" + name
               + ", score=" + score + "]";
    }
    @Override
    public int hashCode() {
       // TODO Auto-generated method stub
       return this.getAssociateId()%4;
    }
    @Override
    public boolean equals(Object obj) {
       Employee arg=(Employee) obj;
       return arg.getAssociateId()==this.getAssociateId();
    }
    @Override
    public int compareTo(Employee o) {
       //sort by associate name asc, score desc
       if(this.getName().equals(o.getName()))
           return o.getScore()-this.getScore();
       else
           return this.getName().compareTo(o.getName());
    }
    
    
}
