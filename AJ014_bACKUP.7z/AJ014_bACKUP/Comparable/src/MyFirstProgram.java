import java.util.TreeSet;

public class MyFirstProgram {

    public static void main(String[] args) {
       TreeSet<Employee> employeeSet=new TreeSet<>();
       employeeSet.add(new Employee(12, "Akbar",90));
       employeeSet.add(new Employee(13, "Bhuvaneshwar",99));
       employeeSet.add(new Employee(14,"Zaheer",100));
       employeeSet.add(new Employee(15, "Jag",50));
       employeeSet.add(new Employee(16, "Farooq",20));
       employeeSet.add(new Employee(17,"Akbar",100));
       employeeSet.add(new Employee(18, "Zaheer",80));
       for(Employee e : employeeSet)
           System.out.println(e);
    }

}
