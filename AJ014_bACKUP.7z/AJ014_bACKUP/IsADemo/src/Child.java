
public class Child extends Parent {

	Child()
	{			
		super("Raffic");
		super.a=200;
		System.out.println("From Child Constr");
	}
	void childMet()
	{
		System.out.println("From Child Method "+a);
	}
}
