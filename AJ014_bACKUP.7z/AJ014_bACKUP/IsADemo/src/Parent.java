
public class Parent {
	
	int a;
	Parent()
	{	
		System.out.println("From Parent Constructor");
	}
	Parent(String sna)
	{
		System.out.println("From Param Parent Constr :"+sna);
	}
	void parentMet()
	{
		System.out.println("from parent Method");
	}

}
