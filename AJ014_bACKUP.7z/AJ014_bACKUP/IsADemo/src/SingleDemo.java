
public class SingleDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child C=new Child();
		C.a=100;
		C.childMet();
		C.parentMet();		
	}

}
