import java.util.*;  
public class IteratingCollections{  
    public static void main(String[] args) {       
       List<String> list=new ArrayList<String>();  
       list.add("Raffic");         
       list.add("Rajesh");       
       list.add("Ram");         
       list.add("Gully");         
       list.add("Karthi");                
       list.forEach(          
           // lambda expression        
           (names)->System.out.println(names)         
       );     
    }  
}