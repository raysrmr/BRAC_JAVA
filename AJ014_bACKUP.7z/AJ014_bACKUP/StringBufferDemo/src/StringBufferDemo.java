
public class StringBufferDemo {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer sb1=new StringBuffer();
		StringBuffer sb2=new StringBuffer("");
		

	}

}
