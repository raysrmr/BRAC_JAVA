import java.util.*;  
class TestAnnotation2{  
	public static void main(String args[]){  
ArrayList<String> list=new ArrayList<>();  
list.add("sonoo");  
list.add("vimal");  
list.add("ratan");  
  
for(Object obj:list)  
System.out.println(obj);  
  
}}  