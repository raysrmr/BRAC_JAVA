import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;  
public class LocalDateTimeDemo {  
    public static void main(String[] args) {  
    	//getting current date and time using now() method
        LocalDateTime currentDateTime = LocalDateTime.now();  
        System.out.println("Current Date and Time: "+currentDateTime); 
        
        
        LocalDateTime localDateTime =LocalDateTime.of(2017, 10, 21, 11, 32, 55, 678);
    	System.out.println("Given Date Time in default format: "+localDateTime);
        
        //lets see how we can display the current date time in different format
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm a");  
        String newFormat = currentDateTime.format(format);  
        System.out.println("Current Date Time in specified format: "+newFormat);  
    }  
}