import java.time.LocalTime;  
public class LocalTimeDemo {  
  public static void main(String[] args) { 
	//now() method is used for getting the current time 
    LocalTime currentTime = LocalTime.now();  
    System.out.println(currentTime);  
    
    /*of() method is used for creating an instance of LocalTime
     * by using the given hour, minutes and seconds values
     */
    LocalTime localTime = LocalTime.of(15,40,55);  
    System.out.println(localTime);  
  }  
}