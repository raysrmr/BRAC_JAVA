import java.time.LocalDate;
public class LocalDateDemo2 {
   public static void main(String[] args) {
	 LocalDate givenDate1 = LocalDate.of(2017, 6, 23);  
         System.out.println(givenDate1.isLeapYear());  

         LocalDate givenDate2 = LocalDate.of(2012, 10, 20);  
	 System.out.println(givenDate2.isLeapYear()); 

	 LocalDate givenDate3 = LocalDate.of(2000, 11, 14);  
	 System.out.println(givenDate3.isLeapYear()); 
   }
}