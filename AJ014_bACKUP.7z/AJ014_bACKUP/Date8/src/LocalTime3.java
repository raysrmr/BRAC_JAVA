import java.time.LocalTime;  
public class LocalTime3 {  
  public static void main(String[] args) { 
	  //time 16:45:55:222222146
	  LocalTime localTime = LocalTime.of(16, 45, 55, 222222146);
	  System.out.println("Given Time: "+localTime);
	  
	  //plusHours() method adds the specified hours to the given local time
	  LocalTime localTime2 = localTime.plusHours(5);
	  System.out.println("Adding 5 hours to the given time: "+ localTime2);
	  
	  //plusMinutes() method adds the specified minutes to the given local time
	  LocalTime localTime3 = localTime.plusMinutes(7);
	  System.out.println("Adding 7 minutes to the given time: "+localTime3);
	  
	  //plusSeconds() method adds the specified seconds to the given local time
	  LocalTime localTime4 = localTime.plusSeconds(2);
	  System.out.println("Adding 2 seconds to the given time : "+localTime4);
	  
	  //plusNanos() method adds the specified nanoseconds to the given local time
	  LocalTime localTime5 = localTime.plusNanos(14);
	  System.out.println("Adding 14 nanoseconds to the given time: "+localTime5);
  }  
}