import java.time.LocalTime;  
public class LocalTimeDemo2 {  
  public static void main(String[] args) { 
    LocalTime localTime = LocalTime.of(15,40,55, 1234);  
    //getting hour from the LocalTime
    System.out.println("Hour: "+localTime.getHour());  
    
    //getting minutes from the LocalTime
    System.out.println("Minute: "+localTime.getMinute());
    
    //getting seconds from the LocalTime
    System.out.println("Second: "+localTime.getSecond());
    
    //getting nano seconds from the LocalTime
    System.out.println("Nano Second: "+localTime.getNano());
  }  
}