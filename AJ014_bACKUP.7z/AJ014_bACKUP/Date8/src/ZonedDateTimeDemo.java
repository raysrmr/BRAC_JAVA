import java.time.ZonedDateTime;  
import java.time.ZoneId;
public class ZonedDateTimeDemo{  
  public static void main(String[] args) {  
	  
	//current date time with default zone id
      ZonedDateTime zonedDateTime = ZonedDateTime.now();
      System.out.println("Current Date Time: "+zonedDateTime);
	  
	  
     //creating a zone id 
     ZoneId  zoneId = ZoneId.of("Asia/New Delhi"); 
	  
     //ZonedDateTime with the specified date, time and zoneId
     ZonedDateTime zonedDateTime1 =
		ZonedDateTime.of(2019, 10, 29, 22, 10, 45, 999, zoneId);
     System.out.println("ZonedDateTime: "+zonedDateTime1);
  }  
}