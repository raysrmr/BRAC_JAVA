import java.time.LocalDateTime;  
import java.time.format.DateTimeFormatter;  
public class DateTimeFormatterDemo2 {  
  public static void main(String[] args) {  
	  
	  LocalDateTime datetime = LocalDateTime.now();
	  DateTimeFormatter dateTimeFormatter = DateTimeFormatter.BASIC_ISO_DATE;
	  String formattedDate = dateTimeFormatter.format(datetime);
	  System.out.println(formattedDate);  
	  
	  DateTimeFormatter dateTimeFormatter2 = DateTimeFormatter.ISO_LOCAL_DATE;
	  String formattedDate2 = dateTimeFormatter2.format(datetime);
	  System.out.println(formattedDate2);
	  
	  DateTimeFormatter dateTimeFormatter3 = DateTimeFormatter.ISO_LOCAL_TIME;
	  String formattedDate3 = dateTimeFormatter3.format(datetime);
	  System.out.println(formattedDate3);
	  
	  DateTimeFormatter dateTimeFormatter4 = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
	  String formattedDate4 = dateTimeFormatter4.format(datetime);
	  System.out.println(formattedDate4);
  }  
}