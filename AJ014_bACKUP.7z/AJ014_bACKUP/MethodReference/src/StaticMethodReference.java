interface MyInterface1{  
    void display();  
}  
public class StaticMethodReference {  
    public static void myMethod(){  
	System.out.println("Static Method");  
    }  
    public static void main(String[] args) {  
	StaticMethodReference obj = new StaticMethodReference();   
	// Method reference using the class
	MyInterface1 ref = StaticMethodReference::myMethod;  
	// Calling the method of functional interface  
	ref.display();  
    }  
}