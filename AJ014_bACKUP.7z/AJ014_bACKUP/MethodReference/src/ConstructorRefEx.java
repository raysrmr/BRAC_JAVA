interface EmployeeFactory {
 
    public abstract Employee getEmployee(String name, String account, Integer salary);
}

public class ConstructorRefEx {
 
    public static void main(String a[]) {
 
        EmployeeFactory empFactory = Employee::new;
        Employee emp = empFactory.getEmployee("Raffic", "Trainer", 18000);
        System.out.println(emp);
    }
}