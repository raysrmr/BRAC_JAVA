import java.util.stream.Collectors;  
import java.util.List;  
import java.util.ArrayList;  
class Student{  
   int id;     
   String name;    
   int age;         
   public Student(int id, String name, int age) {  
        this.id = id;    
        this.name = name;         
        this.age = age;     
   } 
}  
public class Example {  
   public static void main(String[] args) {    
      List<Student> studentlist = new ArrayList<Student>();   
      //Adding Students      
      studentlist.add(new Student(807932,"Lakshmi",22));      
      studentlist.add(new Student(807944,"Vishwarekha",18));        
      studentlist.add(new Student(807951,"Thalbia",22));        
      studentlist.add(new Student(807976,"Vigneshwaran",23));         
      studentlist.add(new Student(808034,"RAMASAMY",18));                  
      //Fetching student names as List       
      List<String> names = studentlist.stream() 
                                   .map(n->n.name) 
                                   .collect(Collectors.toList());
      System.out.println(names);         
   }  
}