import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MapDmeo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<Integer, String> map=new HashMap<Integer,String>();
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter Reg Number:");
			int reg_number=sc.nextInt();
			System.out.println("Enter Name:");
			String name=sc.next();
			map.put(reg_number, name);
		}
		
		System.out.println("Reg Number \t Name");
		for(Map.Entry<Integer, String> mapPair:map.entrySet())
		{
			System.out.println(mapPair.getKey()+"\t"+mapPair.getValue());
		}
		
		map.containsKey(1003);

	}

}
