import java.util.ArrayList;
import java.util.Iterator;

public class CollectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList al=new ArrayList();
		al.add(new String("One"));
		al.add(new Integer(2));
		al.add(new Double(3.0));
		al.add(new Boolean(true));
		
		System.out.println(al.get(0));
		System.out.println(al.get(1));
		System.out.println(al.get(2));
		
		Iterator it=al.iterator();
		while(it.hasNext())
		{
			Object obj=it.next();
			System.out.println(obj);
		}
	}

}
