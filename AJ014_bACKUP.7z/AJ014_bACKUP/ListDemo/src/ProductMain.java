import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    List<Product> list_product=new ArrayList<Product>();
		Scanner sc=new Scanner(System.in);
		System.out.println("How many product want to add :");
		int count=sc.nextInt();
		for(int i=0;i<count;i++)
		{
		System.out.println("Enter the product id");
		long id=sc.nextLong();
		System.out.println("Enter the product name");
		String productName=sc.next();
		System.out.println("Enter the supplier name");
		String supplierName=sc.next();		
		Product P=new Product(id, productName, supplierName);
		list_product.add(P);
		}
		
		
		for(Product pro:list_product)
		{
		System.out.println("Product Id is "+pro.getId());
		System.out.println("Product Name is "+pro.getProductName());
		System.out.println("Supplier Name is "+pro.getSupplierName());
		}
		
		
		
	}

}
