import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<String> list=new ArrayList<String>();
		list.add("Raffi");
		list.add("Rays");
		list.add("Rajesh");
		list.add("Ram");
		
		for(String str:list)
		{
			System.out.println(str);
		}
		System.out.println("*********************");
		
		Collections.sort(list);
		
		for(String str:list)
		{
			System.out.println(str);
		}

	}

}
